#include "def.h"
#include <General_utils.h>

void crash() {  
  BUG;
}

