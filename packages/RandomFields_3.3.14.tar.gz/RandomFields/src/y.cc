#include "def.h"
#include <Basic_utils.h>
#include <General_utils.h>

void crash() {  
  BUG;
}

